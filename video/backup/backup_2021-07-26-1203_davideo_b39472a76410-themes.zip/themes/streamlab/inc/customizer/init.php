<?php

require STREAMLAB_DIR . '/inc/customizer/theme-functions.php';

require STREAMLAB_DIR . '/inc/classes/resize-image.php';
require STREAMLAB_DIR . '/inc/classes/load-more.php';

require STREAMLAB_DIR . '/inc/classes/options.php';


//remove_action( 'masvideos_before_movies_loop', 'masvideos_display_movie_page_title', 99 );

