<?php
  get_template_part( 'template-parts/video/single/style', '1' );

  